<?php

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        echo file_get_contents("http://webapps.groept.be/a15_web04/index.php/NotificationController/notGet");
        //echo file_get_contents("http://localhost/FinalProject/index.php/NotificationController/notGet");
        break;

    case 'POST':

        /*
          $url = "http://webapps.groept.be/a15_web04/index.php/NotificationController/notPost";

          $options = array(
          'http' => array(
          'header' => "Content­type: application/x­www­form­urlencoded",
          'method' => 'POST',
          'content' => http_build_query($_POST),
          ),
          );

          $context = stream_context_create($options);
          $post_response = file_get_contents($url, false, $context);

         */


        $json = $_POST['data'];
        file_put_contents("answers.json", $json . "\r\n", FILE_APPEND);

        $array = json_decode($json);
        $values = $array->values;           // array of strings
        $timestamp = $array->timestamp;   // number
        $card_id = $array->card_id;       // string
        # Connect to the database
        $pdo = new PDO("mysql:dbname=a15_web04;host=localhost", "a15_web04", "web04_secret");
        # Perform the query
        //$stmt = $pdo->prepare("INSERT INTO app_answers (value, timestamp, card_id) VALUES (:value, FROM_UNIXTIME(:timestamp), :card_id)");
        $stmt = $pdo->prepare("INSERT INTO survey_answers (idQuestion, answer) VALUES (:idQuestion, :answer)");

        var_dump($values[0]);
        var_dump($timestamp);
        var_dump($card_id);

        $stmt->bindParam(':idQuestion', $card_id);
        $stmt->bindParam(':answer', $values[0]);

        /* $stmt->bindParam(':value', $values[0]); // TODO insert ALL values
          $stmt->bindParam(':timestamp', $timestamp);
          $stmt->bindParam(':card_id', $card_id); */

        $stmt->debugDumpParams();

        $stmt->execute();

        // Delete out of the survay table

        $stmt2 = $pdo->prepare("DELETE FROM `survey` WHERE `idQuestion` = :id_to_delete");
        $stmt2->bindParam(":id_to_delete", $card_id);
        $stmt2->execute();

        echo "OK";
        break;

    default:
        die("Method " . $_SERVER['REQUEST_METHOD'] . " is not supported.");
}
?>
