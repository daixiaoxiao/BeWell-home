<?php

# Connect to the database
$pdo=new PDO("mysql:dbname=a15_web04;host=localhost","root","root");
//$pdo = new PDO("mysql:dbname=a15_web04;host=localhost", "a15_web04", "web04_secret");


# Perform the query
$q = $_GET["q"];
$query = sprintf("SELECT ID as id, lower(concat_ws(' ', Firstname, Lastname)) as name from a15_web04.user WHERE lower(concat_ws(' ', Firstname, Lastname)) LIKE '%%%s%%' AND Usertype = 2 LIMIT 10", $q);

$statement=$pdo->prepare($query);
$statement->execute();
$results=$statement->fetchAll(PDO::FETCH_ASSOC);
$json=json_encode($results);


echo $json;