<!DOCTYPE html>

<body>

    <!-- container -->
    <div class="container">

        <!-- top message -->
        <div class="topMessage">
            Survey
        </div>

        <!-- empty answer sheet -->
        <div class="lists col-sm-12">
            
            <!-- title of the empty answer sheet -->
            <div class="smalltitle">
                Questions:
            </div>
            
            <!-- empty question field -->
            <div class="paragraph">
                No more questions
            </div>
            
            <!-- return home button -->
            <div class="gohomebutton emptygohome">
                <button type="button" class="btn btn-primary" onclick="location.href = 'homePatient'">Go home</button>
            </div>

            <!-- /empty answer sheet -->
        </div>

        <!-- /container -->
    </div>

</body>

</html>